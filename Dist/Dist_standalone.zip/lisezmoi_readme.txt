Linux Debian standalone programs efibootmgr_Fr and efibootmgr_Us created by pyinstaller for efibootmgr_Fr.py and efibootmgr_Us.py 

create on your desktop a launcher that starts efibootmgr_us or efibootmgr_Fr in a terminal (mandatory), with icon efibootmgr_nvram.png. That's all.



Les programmes autonomes efibootmgr_Fr et efibootmgr_Us ont été créés par le programme pyinstaller sous Debian Linux à partir de efibootmgr_Fr.py et efibootmgr_Us.py.

créez sur votre bureau un lanceur qui execute efibootmgr_us ou efibootmgr_Fr dans un terminal (obligatoire), avec l'icône efibootmgr_nvram.png. C'est tout.

