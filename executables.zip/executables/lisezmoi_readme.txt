Linux Debian standalone programs efibootmgr_Fr and efibootmgr_Us created by pyinstaller for efibootmgr_Fr.py and efibootmgr_Us.py 

create on your desktop a launcher that starts efibootmgr_us or efibootmgr_Fr in a terminal (mandatory), with icon efibootmgr_nvram.png. That' all.

créez sur votre bureau un lanceur qui lance efibootmgr_us ou efibootmgr_Fr dans un terminal (obligatoire), avec l'icône efibootmgr_nvram.png. C'est tout.

