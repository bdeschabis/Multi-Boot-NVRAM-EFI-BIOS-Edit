#!/bin/bash
sudo python3 /home/bernard/a/efibootmgr_Us/efibootmgr_Us.py
read a
